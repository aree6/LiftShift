# API Integration Guide

This guide shows how to integrate the Hevy API import into the existing LiftShift codebase.

## Files Added

```
frontend/src/
├── lib/
│   └── hevy-api.ts          # Hevy API client + data transformation
└── components/
    └── ApiImport.tsx        # React component for API key entry
```

## Integration Steps

### 1. Add API Import Tab to ImportModal

In `frontend/src/components/ImportModal.tsx` (or equivalent), add a tab for API import:

```tsx
import { useState } from 'react';
import ApiImport from './ApiImport';

export function ImportModal({ onClose, onImport }) {
  const [activeTab, setActiveTab] = useState<'csv' | 'api'>('csv');

  return (
    <div className="import-modal">
      {/* Tab switcher */}
      <div className="import-tabs">
        <button 
          className={activeTab === 'csv' ? 'active' : ''} 
          onClick={() => setActiveTab('csv')}
        >
          Import CSV
        </button>
        <button 
          className={activeTab === 'api' ? 'active' : ''} 
          onClick={() => setActiveTab('api')}
        >
          Connect API
        </button>
      </div>

      {/* Tab content */}
      {activeTab === 'csv' ? (
        <CsvImport onImport={onImport} />
      ) : (
        <ApiImport 
          onImportComplete={(data) => {
            onImport(data);
            onClose();
          }}
          onError={(error) => {
            // Handle error display
            console.error(error);
          }}
        />
      )}
    </div>
  );
}
```

### 2. Add "Refresh" Button to Dashboard

For users who connected via API, add a refresh button:

```tsx
import HevyApiClient, { transformToLiftShiftFormat } from '../lib/hevy-api';

function RefreshButton({ onRefresh }) {
  const [loading, setLoading] = useState(false);
  
  const handleRefresh = async () => {
    const apiKey = localStorage.getItem('liftshift_hevy_api_key');
    if (!apiKey) {
      alert('No API key saved. Please reconnect via Settings.');
      return;
    }

    setLoading(true);
    try {
      const client = new HevyApiClient(apiKey);
      const workouts = await client.getAllWorkouts();
      const templates = await client.getAllExerciseTemplates();
      const data = transformToLiftShiftFormat(workouts, templates);
      onRefresh(data);
    } catch (err) {
      console.error('Refresh failed:', err);
    } finally {
      setLoading(false);
    }
  };

  // Only show if API key exists
  const hasApiKey = !!localStorage.getItem('liftshift_hevy_api_key');
  if (!hasApiKey) return null;

  return (
    <button onClick={handleRefresh} disabled={loading}>
      {loading ? 'Syncing...' : '🔄 Sync from Hevy'}
    </button>
  );
}
```

### 3. Update Data Store

If using a store (Zustand/Redux/etc), add source tracking:

```tsx
// In your store
interface WorkoutStore {
  data: LiftShiftData | null;
  source: 'csv' | 'hevy-api' | null;
  importedAt: Date | null;
  
  setData: (data: LiftShiftData) => void;
}

// When importing
setData(data) {
  this.data = data;
  this.source = data.source;
  this.importedAt = data.importedAt;
}
```

### 4. Handle Data Persistence

The API data is stored in localStorage alongside CSV data. Add logic to detect source:

```tsx
// On app load
const savedData = localStorage.getItem('liftshift_workout_data');
const apiKey = localStorage.getItem('liftshift_hevy_api_key');

if (savedData) {
  const data = JSON.parse(savedData);
  
  // Check if it was from API and offer refresh
  if (data.source === 'hevy-api' && apiKey) {
    // Optionally auto-refresh on load
    // Or show "Last synced X hours ago" with refresh button
  }
}
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────┐
│                        User Choice                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌─────────────┐              ┌─────────────────────────┐ │
│   │  CSV Import │              │     API Import          │ │
│   ├─────────────┤              ├─────────────────────────┤ │
│   │ Upload file │              │ Enter API key           │ │
│   │ Parse CSV   │              │ Fetch /v1/workouts      │ │
│   │ Transform   │              │ Fetch /v1/templates     │ │
│   └──────┬──────┘              │ Transform               │ │
│          │                     └────────────┬────────────┘ │
│          │                                  │              │
│          └──────────────┬───────────────────┘              │
│                         │                                  │
│                         ▼                                  │
│          ┌──────────────────────────────┐                 │
│          │    LiftShiftData             │                 │
│          │    (unified format)          │                 │
│          └──────────────┬───────────────┘                 │
│                         │                                  │
│                         ▼                                  │
│          ┌──────────────────────────────┐                 │
│          │    Analytics Engine          │                 │
│          │    (unchanged)               │                 │
│          └──────────────────────────────┘                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## API Limitations

| Endpoint | Max Page Size | Notes |
|----------|---------------|-------|
| `/v1/workouts` | 10 | Slower to paginate |
| `/v1/exercise_templates` | 100 | Fast |
| `/v1/routines` | TBD | Not used yet |

For users with 500+ workouts, initial sync may take 30-60 seconds.

## Security Notes

- API key stored in localStorage (browser only)
- Key is never sent to any server except api.hevyapp.com
- User can clear saved key at any time
- Consider adding encryption for extra security:

```tsx
// Optional: Encrypt before storing
import CryptoJS from 'crypto-js';

const encryptKey = (key: string) => 
  CryptoJS.AES.encrypt(key, 'liftshift-local-key').toString();

const decryptKey = (encrypted: string) => 
  CryptoJS.AES.decrypt(encrypted, 'liftshift-local-key').toString(CryptoJS.enc.Utf8);
```
