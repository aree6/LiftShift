/**
 * Hevy API Client for LiftShift
 * 
 * Replaces CSV import with live API data fetching.
 * Requires Hevy Pro subscription for API access.
 * 
 * Get your API key at: https://hevy.com/settings?developer
 */

const HEVY_API_BASE = 'https://api.hevyapp.com/v1';

export interface HevyWorkout {
  id: string;
  title: string;
  description: string;
  start_time: string;
  end_time: string;
  exercises: HevyExercise[];
}

export interface HevyExercise {
  index: number;
  title: string;
  exercise_template_id: string;
  sets: HevySet[];
}

export interface HevySet {
  index: number;
  set_type: 'normal' | 'warmup' | 'dropset' | 'failure';
  weight_kg: number | null;
  reps: number | null;
  distance_meters: number | null;
  duration_seconds: number | null;
  rpe: number | null;
}

export interface HevyExerciseTemplate {
  id: string;
  title: string;
  type: string;
  primary_muscle_group: string;
  secondary_muscle_groups: string[];
  equipment: string;
}

export interface HevyApiResponse<T> {
  page: number;
  page_count: number;
  [key: string]: T[] | number;
}

class HevyApiClient {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private async fetch<T>(endpoint: string, params: Record<string, string> = {}): Promise<T> {
    const url = new URL(`${HEVY_API_BASE}${endpoint}`);
    Object.entries(params).forEach(([key, value]) => url.searchParams.append(key, value));

    const response = await fetch(url.toString(), {
      headers: {
        'api-key': this.apiKey,
        'accept': 'application/json',
      },
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(`Hevy API Error: ${error.error || response.statusText}`);
    }

    return response.json();
  }

  /**
   * Fetch all workouts (handles pagination automatically)
   */
  async getAllWorkouts(onProgress?: (loaded: number, total: number) => void): Promise<HevyWorkout[]> {
    const allWorkouts: HevyWorkout[] = [];
    let page = 1;
    let pageCount = 1;

    do {
      const response = await this.fetch<HevyApiResponse<HevyWorkout>>('/workouts', {
        page: page.toString(),
        pageSize: '10', // Max allowed for workouts endpoint
      });

      const workouts = response.workouts as HevyWorkout[];
      allWorkouts.push(...workouts);
      pageCount = response.page_count;

      if (onProgress) {
        onProgress(page, pageCount);
      }

      page++;
    } while (page <= pageCount);

    return allWorkouts;
  }

  /**
   * Fetch all exercise templates (handles pagination automatically)
   */
  async getAllExerciseTemplates(onProgress?: (loaded: number, total: number) => void): Promise<HevyExerciseTemplate[]> {
    const allTemplates: HevyExerciseTemplate[] = [];
    let page = 1;
    let pageCount = 1;

    do {
      const response = await this.fetch<HevyApiResponse<HevyExerciseTemplate>>('/exercise_templates', {
        page: page.toString(),
        pageSize: '100', // Max allowed for templates endpoint
      });

      const templates = response.exercise_templates as HevyExerciseTemplate[];
      allTemplates.push(...templates);
      pageCount = response.page_count;

      if (onProgress) {
        onProgress(page, pageCount);
      }

      page++;
    } while (page <= pageCount);

    return allTemplates;
  }

  /**
   * Test API connection
   */
  async testConnection(): Promise<boolean> {
    try {
      await this.fetch('/workouts', { page: '1', pageSize: '1' });
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Transform Hevy API data to LiftShift's internal format
 * This matches the structure expected by LiftShift's analytics engine
 */
export function transformToLiftShiftFormat(
  workouts: HevyWorkout[],
  templates: HevyExerciseTemplate[]
): LiftShiftData {
  // Build template lookup map
  const templateMap = new Map(templates.map(t => [t.id, t]));

  const transformedWorkouts = workouts.map(workout => {
    const exercises = workout.exercises.map(exercise => {
      const template = templateMap.get(exercise.exercise_template_id);
      
      return {
        name: exercise.title,
        muscleGroup: template?.primary_muscle_group || 'other',
        secondaryMuscles: template?.secondary_muscle_groups || [],
        equipment: template?.equipment || 'other',
        sets: exercise.sets
          .filter(set => set.set_type !== 'warmup') // Exclude warmup sets like original
          .map(set => ({
            type: set.set_type,
            weight: set.weight_kg,
            reps: set.reps,
            distance: set.distance_meters,
            duration: set.duration_seconds,
            rpe: set.rpe,
          })),
      };
    });

    return {
      id: workout.id,
      title: workout.title,
      date: new Date(workout.start_time),
      duration: workout.end_time && workout.start_time
        ? (new Date(workout.end_time).getTime() - new Date(workout.start_time).getTime()) / 60000
        : 0,
      exercises,
    };
  });

  // Sort by date (newest first)
  transformedWorkouts.sort((a, b) => b.date.getTime() - a.date.getTime());

  return {
    workouts: transformedWorkouts,
    templates: templates.map(t => ({
      id: t.id,
      name: t.title,
      muscleGroup: t.primary_muscle_group,
      secondaryMuscles: t.secondary_muscle_groups,
      equipment: t.equipment,
      type: t.type,
    })),
    importedAt: new Date(),
    source: 'hevy-api',
  };
}

// LiftShift's internal data types
export interface LiftShiftData {
  workouts: LiftShiftWorkout[];
  templates: LiftShiftTemplate[];
  importedAt: Date;
  source: 'csv' | 'hevy-api';
}

export interface LiftShiftWorkout {
  id: string;
  title: string;
  date: Date;
  duration: number;
  exercises: LiftShiftExercise[];
}

export interface LiftShiftExercise {
  name: string;
  muscleGroup: string;
  secondaryMuscles: string[];
  equipment: string;
  sets: LiftShiftSet[];
}

export interface LiftShiftSet {
  type: string;
  weight: number | null;
  reps: number | null;
  distance: number | null;
  duration: number | null;
  rpe: number | null;
}

export interface LiftShiftTemplate {
  id: string;
  name: string;
  muscleGroup: string;
  secondaryMuscles: string[];
  equipment: string;
  type: string;
}

export default HevyApiClient;
