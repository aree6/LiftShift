/**
 * API Import Component for LiftShift
 * 
 * Provides UI for connecting via Hevy API key instead of CSV import.
 * Add this as a tab/option in the existing ImportModal component.
 */

import { useState, useCallback } from 'react';
import HevyApiClient, { transformToLiftShiftFormat, type LiftShiftData } from '../lib/hevy-api';

interface ApiImportProps {
  onImportComplete: (data: LiftShiftData) => void;
  onError: (error: string) => void;
}

interface ImportProgress {
  stage: 'idle' | 'connecting' | 'workouts' | 'templates' | 'processing' | 'complete' | 'error';
  message: string;
  progress?: number;
}

const API_KEY_STORAGE_KEY = 'liftshift_hevy_api_key';

export function ApiImport({ onImportComplete, onError }: ApiImportProps) {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem(API_KEY_STORAGE_KEY) || '');
  const [saveKey, setSaveKey] = useState(true);
  const [progress, setProgress] = useState<ImportProgress>({ stage: 'idle', message: '' });

  const handleImport = useCallback(async () => {
    if (!apiKey.trim()) {
      onError('Please enter your Hevy API key');
      return;
    }

    const client = new HevyApiClient(apiKey.trim());

    try {
      // Test connection
      setProgress({ stage: 'connecting', message: 'Testing API connection...' });
      const isValid = await client.testConnection();
      
      if (!isValid) {
        throw new Error('Invalid API key. Please check your key and try again.');
      }

      // Save key if requested
      if (saveKey) {
        localStorage.setItem(API_KEY_STORAGE_KEY, apiKey.trim());
      } else {
        localStorage.removeItem(API_KEY_STORAGE_KEY);
      }

      // Fetch workouts
      setProgress({ stage: 'workouts', message: 'Fetching workouts...', progress: 0 });
      const workouts = await client.getAllWorkouts((loaded, total) => {
        setProgress({
          stage: 'workouts',
          message: `Fetching workouts (page ${loaded}/${total})...`,
          progress: (loaded / total) * 100,
        });
      });

      // Fetch templates
      setProgress({ stage: 'templates', message: 'Fetching exercise templates...', progress: 0 });
      const templates = await client.getAllExerciseTemplates((loaded, total) => {
        setProgress({
          stage: 'templates',
          message: `Fetching templates (page ${loaded}/${total})...`,
          progress: (loaded / total) * 100,
        });
      });

      // Transform data
      setProgress({ stage: 'processing', message: 'Processing data...' });
      const data = transformToLiftShiftFormat(workouts, templates);

      setProgress({
        stage: 'complete',
        message: `Imported ${workouts.length} workouts and ${templates.length} exercises!`,
      });

      onImportComplete(data);

    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error occurred';
      setProgress({ stage: 'error', message });
      onError(message);
    }
  }, [apiKey, saveKey, onImportComplete, onError]);

  const handleClearKey = useCallback(() => {
    localStorage.removeItem(API_KEY_STORAGE_KEY);
    setApiKey('');
  }, []);

  const isLoading = ['connecting', 'workouts', 'templates', 'processing'].includes(progress.stage);

  return (
    <div className="api-import">
      <div className="api-import__header">
        <h3>Connect with Hevy API</h3>
        <p className="api-import__description">
          Enter your Hevy API key to sync your workout data directly.
          <br />
          <a 
            href="https://hevy.com/settings?developer" 
            target="_blank" 
            rel="noopener noreferrer"
            className="api-import__link"
          >
            Get your API key here →
          </a>
        </p>
        <p className="api-import__note">
          Requires Hevy Pro subscription
        </p>
      </div>

      <div className="api-import__form">
        <div className="api-import__field">
          <label htmlFor="api-key">API Key</label>
          <input
            id="api-key"
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="Enter your Hevy API key"
            disabled={isLoading}
            className="api-import__input"
          />
        </div>

        <div className="api-import__checkbox">
          <input
            id="save-key"
            type="checkbox"
            checked={saveKey}
            onChange={(e) => setSaveKey(e.target.checked)}
            disabled={isLoading}
          />
          <label htmlFor="save-key">Remember API key (stored locally)</label>
        </div>

        {progress.stage !== 'idle' && (
          <div className={`api-import__progress api-import__progress--${progress.stage}`}>
            {progress.progress !== undefined && (
              <div className="api-import__progress-bar">
                <div 
                  className="api-import__progress-fill" 
                  style={{ width: `${progress.progress}%` }}
                />
              </div>
            )}
            <p>{progress.message}</p>
          </div>
        )}

        <div className="api-import__actions">
          <button
            onClick={handleImport}
            disabled={isLoading || !apiKey.trim()}
            className="api-import__button api-import__button--primary"
          >
            {isLoading ? 'Importing...' : 'Import from Hevy'}
          </button>

          {localStorage.getItem(API_KEY_STORAGE_KEY) && (
            <button
              onClick={handleClearKey}
              disabled={isLoading}
              className="api-import__button api-import__button--secondary"
            >
              Clear Saved Key
            </button>
          )}
        </div>
      </div>

      <style>{`
        .api-import {
          padding: 1.5rem;
        }

        .api-import__header {
          margin-bottom: 1.5rem;
        }

        .api-import__header h3 {
          margin: 0 0 0.5rem;
          font-size: 1.25rem;
        }

        .api-import__description {
          color: var(--text-secondary, #666);
          margin: 0;
        }

        .api-import__link {
          color: var(--accent-color, #3b82f6);
        }

        .api-import__note {
          font-size: 0.875rem;
          color: var(--text-muted, #888);
          margin-top: 0.5rem;
        }

        .api-import__field {
          margin-bottom: 1rem;
        }

        .api-import__field label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 500;
        }

        .api-import__input {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid var(--border-color, #ddd);
          border-radius: 0.5rem;
          font-size: 1rem;
          background: var(--input-bg, #fff);
          color: var(--text-primary, #333);
        }

        .api-import__input:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .api-import__checkbox {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          margin-bottom: 1rem;
        }

        .api-import__progress {
          padding: 1rem;
          border-radius: 0.5rem;
          margin-bottom: 1rem;
        }

        .api-import__progress--connecting,
        .api-import__progress--workouts,
        .api-import__progress--templates,
        .api-import__progress--processing {
          background: var(--info-bg, #e0f2fe);
          color: var(--info-text, #0369a1);
        }

        .api-import__progress--complete {
          background: var(--success-bg, #dcfce7);
          color: var(--success-text, #166534);
        }

        .api-import__progress--error {
          background: var(--error-bg, #fee2e2);
          color: var(--error-text, #dc2626);
        }

        .api-import__progress-bar {
          height: 4px;
          background: rgba(0, 0, 0, 0.1);
          border-radius: 2px;
          margin-bottom: 0.5rem;
          overflow: hidden;
        }

        .api-import__progress-fill {
          height: 100%;
          background: currentColor;
          transition: width 0.3s ease;
        }

        .api-import__actions {
          display: flex;
          gap: 0.75rem;
        }

        .api-import__button {
          padding: 0.75rem 1.5rem;
          border-radius: 0.5rem;
          font-size: 1rem;
          font-weight: 500;
          cursor: pointer;
          transition: opacity 0.2s;
        }

        .api-import__button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .api-import__button--primary {
          background: var(--accent-color, #3b82f6);
          color: white;
          border: none;
        }

        .api-import__button--secondary {
          background: transparent;
          color: var(--text-secondary, #666);
          border: 1px solid var(--border-color, #ddd);
        }
      `}</style>
    </div>
  );
}

export default ApiImport;
