# LiftShift Fork - API-Powered Edition

This fork adds **Hevy API integration** for live data sync instead of CSV imports.

## Features Added
- 🔑 Connect with Hevy API key (no more CSV exports)
- 🔄 Live sync button to refresh data
- 🐳 Docker deployment ready
- 🚀 Auto-deploy on git push via GitHub Actions + Watchtower

---

## Quick Start

### 1. Fork the Repository

1. Go to GitHub and fork this repo to your account
2. Clone your fork:
   ```bash
   git clone https://github.com/YOUR_USERNAME/liftshift.git
   cd liftshift
   ```

### 2. Enable GitHub Container Registry

1. Go to your fork's **Settings → Actions → General**
2. Under "Workflow permissions", select **Read and write permissions**
3. Save

### 3. Deploy on Proxmox

SSH into your Proxmox host (or Docker VM):

```bash
# Create app directory
mkdir -p /opt/liftshift
cd /opt/liftshift

# Download docker-compose
wget https://raw.githubusercontent.com/YOUR_USERNAME/liftshift/main/docker-compose.yml

# Edit to set your GitHub username
nano docker-compose.yml
# Change: ghcr.io/yourusername/liftshift → ghcr.io/YOUR_USERNAME/liftshift

# Login to GitHub Container Registry
echo "YOUR_GITHUB_PAT" | docker login ghcr.io -u YOUR_USERNAME --password-stdin

# Start the stack
docker compose up -d
```

### 4. Access LiftShift

| Method | URL |
|--------|-----|
| Local | `http://YOUR_SERVER_IP:3000` |
| Tailscale | `http://proxmox:3000` |
| Tailscale Funnel | `tailscale funnel 3000` → public HTTPS |

---

## Auto-Deploy Setup

Once configured, the flow is:

```
Push to GitHub → GitHub Actions builds image → Pushes to GHCR → Watchtower pulls → Container restarts
```

Watchtower checks every 5 minutes. For faster deploys, you can:

1. **Manual trigger:**
   ```bash
   docker exec watchtower-liftshift /watchtower --run-once
   ```

2. **Webhook trigger:** Set up n8n to call watchtower on GitHub webhook

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NODE_ENV` | Environment mode | `production` |
| `PORT` | Server port | `3000` |

---

## GitHub PAT Setup

To pull images from GHCR, create a Personal Access Token:

1. Go to GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Generate new token with `read:packages` scope
3. Use this token for `docker login`

---

## Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build
```

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│                  Your Proxmox                   │
├─────────────────────────────────────────────────┤
│  Docker                                         │
│  ├── liftshift        (this app)               │
│  ├── watchtower       (auto-updates)           │
│  ├── n8n              (your automations)       │
│  └── postgresql       (optional data store)    │
├─────────────────────────────────────────────────┤
│  Tailscale Funnel                              │
│  └── https://liftshift.xxx.ts.net             │
└─────────────────────────────────────────────────┘
         ↑
         │ HTTPS
         ↓
┌─────────────────────────────────────────────────┐
│              Hevy API                           │
│  └── api.hevyapp.com/v1/workouts               │
└─────────────────────────────────────────────────┘
```

---

## Credits

- Original project: [aree6/LiftShift](https://github.com/aree6/LiftShift)
- Licensed under AGPL-3.0
