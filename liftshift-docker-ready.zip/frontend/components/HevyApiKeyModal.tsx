import React, { useState, useCallback } from 'react';
import { ArrowLeft, Key, ExternalLink, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

interface HevyApiKeyModalProps {
  onSubmit: (apiKey: string) => void;
  onBack: () => void;
  onClose?: () => void;
  isLoading?: boolean;
  error?: string | null;
}

export const HevyApiKeyModal: React.FC<HevyApiKeyModalProps> = ({
  onSubmit,
  onBack,
  onClose,
  isLoading = false,
  error = null,
}) => {
  const [apiKey, setApiKey] = useState('');
  const [saveKey, setSaveKey] = useState(true);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (apiKey.trim() && !isLoading) {
      onSubmit(apiKey.trim());
    }
  }, [apiKey, isLoading, onSubmit]);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 overflow-y-auto overscroll-contain">
      <div className="min-h-full w-full px-2 sm:px-3 pt-10 pb-6 sm:pt-12 sm:pb-6">
        <div className="max-w-lg mx-auto slide-in-from-top-2">
          <div className="bg-black/60 border border-slate-700/50 rounded-2xl p-5 sm:p-6">
            {/* Header */}
            <div className="grid grid-cols-3 items-start gap-3">
              <div className="flex items-center justify-start">
                <button
                  type="button"
                  onClick={onBack}
                  disabled={isLoading}
                  className="inline-flex items-center justify-center w-9 h-9 rounded-md text-xs font-semibold bg-black/60 hover:bg-black/70 border border-slate-700/50 text-slate-200 disabled:opacity-50"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>

              <div className="text-center">
                <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">API Key</h2>
                <p className="mt-1 text-sm text-slate-300">Connect with Hevy's official API</p>
              </div>

              <div className="flex items-center justify-end">
                {onClose && (
                  <button
                    type="button"
                    onClick={onClose}
                    disabled={isLoading}
                    className="inline-flex items-center justify-center h-9 px-3 rounded-md text-xs font-semibold bg-black/60 hover:bg-black/70 border border-slate-700/50 text-slate-200 disabled:opacity-50"
                  >
                    Close
                  </button>
                )}
              </div>
            </div>

            {/* Info banner */}
            <div className="mt-5 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <div className="flex items-start gap-3">
                <Key className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-slate-200">
                  <p className="font-medium text-blue-300">Requires Hevy Pro</p>
                  <p className="mt-1 text-slate-400">
                    Get your API key from Hevy settings. Your key is stored locally and sent only to Hevy.
                  </p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <label htmlFor="api-key" className="block text-sm font-medium text-slate-200 mb-2">
                  Hevy API Key
                </label>
                <input
                  id="api-key"
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API key"
                  disabled={isLoading}
                  autoComplete="off"
                  className="w-full px-4 py-3 rounded-lg bg-black/40 border border-slate-700/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 disabled:opacity-50"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  id="save-key"
                  type="checkbox"
                  checked={saveKey}
                  onChange={(e) => setSaveKey(e.target.checked)}
                  disabled={isLoading}
                  className="w-4 h-4 rounded border-slate-600 bg-black/40 text-blue-500 focus:ring-blue-500/50"
                />
                <label htmlFor="save-key" className="text-sm text-slate-300">
                  Remember API key for future syncs
                </label>
              </div>

              {/* Error message */}
              {error && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                  <div className="flex items-center gap-2 text-red-400">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span className="text-sm">{error}</span>
                  </div>
                </div>
              )}

              {/* Submit button */}
              <button
                type="submit"
                disabled={!apiKey.trim() || isLoading}
                className="w-full py-3 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Syncing...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>Connect & Sync</span>
                  </>
                )}
              </button>
            </form>

            {/* Get API key link */}
            <div className="mt-5 text-center">
              <a
                href="https://hevy.com/settings?developer"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm text-blue-400 hover:text-blue-300 transition-colors"
              >
                <span>Get your API key from Hevy</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* Privacy note */}
            <div className="mt-4 text-[11px] text-slate-500 text-center">
              Your API key is stored in your browser only. Data is fetched directly from Hevy's servers.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
