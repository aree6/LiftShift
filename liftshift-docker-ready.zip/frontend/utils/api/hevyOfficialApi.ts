/**
 * Official Hevy API Client (via Backend Proxy)
 * 
 * Calls our backend which proxies to the official Hevy API.
 * Requires Hevy Pro subscription for an API key.
 * Get your API key at: https://hevy.com/settings?developer
 */

import type { WorkoutSet } from '../../types';
import { getBackendBaseUrl } from './hevyBackend';

interface BackendSetsResponse {
  sets: WorkoutSet[];
  meta?: {
    workouts?: number;
  };
}

const buildBackendUrl = (path: string): string => {
  const base = getBackendBaseUrl();
  return base ? `${base}${path}` : path;
};

/**
 * Validate an API key
 */
export async function validateHevyApiKey(apiKey: string): Promise<boolean> {
  try {
    const res = await fetch(buildBackendUrl('/api/hevy/official/validate'), {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ apiKey }),
    });

    if (!res.ok) return false;
    const data = await res.json();
    return data.valid === true;
  } catch {
    return false;
  }
}

/**
 * Fetch all workout sets via the official API
 */
export async function fetchSetsViaOfficialApi(apiKey: string): Promise<BackendSetsResponse> {
  const res = await fetch(buildBackendUrl('/api/hevy/official/sets'), {
    method: 'GET',
    headers: {
      'content-type': 'application/json',
      'hevy-api-key': apiKey,
    },
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(error.error || `API Error: ${res.status}`);
  }

  return res.json();
}

/**
 * Full sync: validate key, fetch all sets
 */
export async function syncFromHevyApi(
  apiKey: string,
  onProgress?: (stage: string) => void
): Promise<WorkoutSet[]> {
  // Validate
  onProgress?.('Validating API key...');
  const isValid = await validateHevyApiKey(apiKey);
  if (!isValid) {
    throw new Error('Invalid API key. Please check your key and try again.');
  }

  // Fetch
  onProgress?.('Fetching workouts...');
  const response = await fetchSetsViaOfficialApi(apiKey);

  onProgress?.(`Imported ${response.meta?.workouts ?? 0} workouts`);

  return response.sets;
}
